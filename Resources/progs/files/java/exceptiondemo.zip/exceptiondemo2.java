import java.io.*;

class exceptiondemo2
{
  public static void main(String args[])
  {
    int a[ ]={10,20,30};
    System.out.println("A[0]="+a[0]);
    System.out.println("A[1]="+a[1]);
    System.out.println("A[2]="+a[2]);
    System.out.println("A[3]="+a[3]);
  }
}