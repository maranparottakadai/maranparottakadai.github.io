package p1;
public class c1
{
  public void display()
  {
    int l=10;
    int h=20;
    System.out.println("I am from first Package");
    int area=l*h;
    System.out.println("Area of the Rectangle="+ area);
  }
}